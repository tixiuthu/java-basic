package bai5;

import java.util.Scanner;

/**
 * Created by nvtien on 7/10/18.
 */
public class Array2 {
    public static void main(String[] args) {
        int n;
        int a[];

        do {
            System.out.print("Nhap n: ");
            Scanner scanner = new Scanner(System.in);
            n = scanner.nextInt();
            a = nhapMang(n);

//            inRaChinhPhuong(a);
//
//            System.out.println();
//
//            taoMangB(a);

            cauC(a);

        } while (n <= 0);
    }

    public static int[] nhapMang(int n) {
        Scanner scanner = new Scanner(System.in);
        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            do {
                System.out.printf("Nhap a[%d] = ", i);
                a[i] = scanner.nextInt();
            } while (a[i] < 0);
        }
        return a;
    }

    public static void inRaChinhPhuong(int[] a) {
        for (int i = 0; i < a.length; i++) {
            double canPhanTu = Math.sqrt(a[i]); // 2.0
            double phanThapPhan = canPhanTu - (int) canPhanTu; // 2.0 - 2 = 0.0
            if (phanThapPhan == 0) {
                System.out.printf("%d, ", a[i]);
            }
        }
    }

    public static void taoMangB(int[] a) {
        int[] b = new int[a.length];

        b[0] = a[0];

        for (int i = 1; i < a.length; i++) {
            b[i] = a[i] + a[i - 1];
        }

        for (int ptb : b) {
            System.out.print(ptb + "\t");
        }
    }

    public static void cauC(int[] a) {
        Scanner sc = new Scanner(System.in);
        int x, y, z;

        for (int i = 0; i < a.length; i++) {
            for (int j = i; j < a.length; j++) {
                if (a[i] < a[j]) {
                    int tmp = a[i];
                    a[i] = a[j];
                    a[j] = tmp;
                }
            }
        }

        System.out.print("X = ");
        x = sc.nextInt();
        System.out.print("Y = ");
        y = sc.nextInt();
        System.out.print("Z = ");
        z = sc.nextInt();

        int[] b = new int[a.length + 3];

        for (int i = 0; i < a.length; i++) {
            b[i] = a[i];
        }

        int vtx = -1;
        for (int i = 0; i < a.length; i++) {
            if (x >= a[i]) {
                vtx = i;
                break;
            }
        }

        System.out.println(vtx);

        // Di chuyen toan bo ve sau 1 vi tri tu vtx
        for (int i = b.length - 1; i >= vtx; i--) {
            b[i] = b[i - 1];
        }
        if (vtx > 0) {
            b[vtx] = x;
        } else {
            b[b.length - 1] = x;
        }

        for (int ptb : b) {
            System.out.print(ptb + "\t");
        }
    }
}
