package bai9.interfaces;
/**
 *
 * Created by nththuy on 12/12/18.
 */
public class Square2 implements Shape2 {
    private int soCanh = 4;

    public int getSoCanh() {
        return soCanh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }

    @Override
    public void print() {
        System.out.println("So canh = " + this.soCanh);
    }
}
