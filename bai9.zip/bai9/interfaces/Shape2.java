package bai9.interfaces;

/**
 * Created by nththuy on 12/12/18.
 */
public interface Shape2 {
    void print();
}
