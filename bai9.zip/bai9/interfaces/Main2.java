package bai9.interfaces;

/**
 * Created by nththuy on 12/12/18.
 */
public class Main2 {
    public static void main(String[] args) {
        Shape2 shape2 = new Square2();
        shape2.print();
    }
}
