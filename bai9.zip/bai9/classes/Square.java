package bai9.classes;

/**
 * Created by nththuy on 12/12/18.
 */
public class Square extends Shape {


    @Override
    public void print() {
        System.out.println("So canh Hinh vuong: " + this.getSoCanh());
//        super.print();
    }
}
