package bai9.classes;

/**
 * Created by nththuy on 12/12/18.
 */
public class Circle extends Shape {
    private int banKinh;

    public int getBanKinh() {
        return banKinh;
    }

    public void setBanKinh(int banKinh) {
        this.banKinh = banKinh;
    }

    public float dienTich() {
        return 3.14F * this.banKinh * this.banKinh;
    }
}
