package bai9.phone;

/**
 * Created by nththuy on 12/12/18.
 */
public class Phone implements IPhone {
    // Khai bao 4 thuoc tinh

    @Override
    public void inputInfor() {
        // Nhap 4 thuoc tinh
    }

    @Override
    public void displayInfor() {

    }
}
