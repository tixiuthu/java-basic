package bai9.phone;

/**
 * Created by nththuy on 12/12/18.
 */
public interface IPhone {
    void inputInfor();
    void displayInfor();
}
