package bai9.hinhchunhat;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by nththuy on 12/12/18.
 */
public class HCNTest {
    public static void main(String[] args) {
        List<Hinhchunhat> hinhchunhatList = new ArrayList<>();
        hinhchunhatList = nhapNHinhChunhat();
        inRaNHinhChuNhat(hinhchunhatList);

        int vitriLonNhat = timHCNLonNhat(hinhchunhatList);
        System.out.println("Dien tich lon nhat la: " + hinhchunhatList.get(vitriLonNhat).dientichHCN());
    }

    /**
     *
     * @param list
     * @return vi tri co dien tich lon nhat
     */
    public static int timHCNLonNhat(List<Hinhchunhat> list) {
        int index = -1;
        int dienTichLonNhat = -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).dientichHCN() > dienTichLonNhat) {
                index = i;
                dienTichLonNhat = list.get(i).dientichHCN();
            }
        }
        return index;
    }

    /**
     *
     * @param list: Tham so dau vao can in
     */
    public static void inRaNHinhChuNhat(List<Hinhchunhat> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.println("HCN thu " + (i + 1) + ":");
            System.out.printf("CD = %d, CR = %d, DT = %d\n", list.get(i).getChieuDai(),
                    list.get(i).getChieuRong(), list.get(i).dientichHCN());
        }
    }

    public static List<Hinhchunhat> nhapNHinhChunhat() {
        List<Hinhchunhat> list = new ArrayList<>();
        int n;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap n: ");
        n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            Hinhchunhat hcn = new Hinhchunhat();
            System.out.print("Nhap chieu dai hinh thu " + (i + 1) + ": ");
            int cd = scanner.nextInt();
            System.out.print("Nhap chieu rong hinh thu " + (i + 1) + ": ");
            int cr = scanner.nextInt();
            hcn.setDaiRong(cd, cr);

            list.add(hcn);
        }
        return list;
    }
}
