package bai4.employee;

/**
 * Created by nththuy on 12/12/18.
 */
public class Employee {

    private String firstName;
    private String lastName;
    private double salary;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }


    public double checkSalary(double salary) {
        if (salary < 0) {
            return 0.0;
        }
        return salary;

    }

    public double nextSalary(double salary) {

        return salary + salary *10/100;

    }


    @Override
    public String toString() {

        return "Full Name "+lastName +" "+ firstName +" - Salary "+salary +" - Next Salary "+nextSalary(salary);
    }

}
