package bai4.invoice;

import java.util.Scanner;

/**
 * Created by nththuy on 7/10/18.
 */
public class Bai2 {
    public static void main(String[] args) {
        Invoice invoice = new Invoice();

        Scanner scanner = new Scanner(System.in);

        System.out.print("MS Hoa Don: ");
        invoice.setMaSoHoaDon(scanner.nextLine());

        System.out.print("So Tien: ");
        invoice.setSoTien(scanner.nextInt());

//        invoice.inHoaDon();
        System.out.println(invoice.toString());
    }
}
