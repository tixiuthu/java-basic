package bai9.hinhchunhat;

/**
 * Created by nththuy on 12/12/18.
 */
public class Hinhchunhat implements HCNInterface {
    int chieuDai;
    int chieuRong;

    @Override
    public int dientichHCN() {
        return this.chieuDai * this.chieuRong;
    }

    @Override
    public int getChieuDai() {
        return this.chieuDai;
    }

    @Override
    public int getChieuRong() {
        return this.chieuRong;
    }

    @Override
    public void setDaiRong(int cd, int cr) {
        this.chieuDai = cd;
        this.chieuRong = cr;
    }
}
