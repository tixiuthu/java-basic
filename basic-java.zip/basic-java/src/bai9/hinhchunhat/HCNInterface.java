package bai9.hinhchunhat;

/**
 * Created by nththuy on 12/12/18.
 */
public interface HCNInterface {
    int dientichHCN();
    int getChieuDai();
    int getChieuRong();
    void setDaiRong(int cd, int cr);
}
