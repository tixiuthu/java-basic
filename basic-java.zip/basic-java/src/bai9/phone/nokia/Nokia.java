package bai9.phone.nokia;


import bai9.phone.Phone;

/**
 * Created by nththuy on 12/12/18.
 */
public class Nokia extends Phone {
    @Override
    public void inputInfor() {
        super.inputInfor();
        System.out.println("Warranty ");
    }

    @Override
    public void displayInfor() {
        super.displayInfor();
    }
}
