package bai9.phone.lg;


import bai9.phone.Phone;

/**
 * Created by nththuy on 12/12/18.
 */
public class LG extends Phone {
}
