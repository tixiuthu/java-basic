package bai9.classes;

/**
 * Created by nththuy on 12/12/18.
 */
public class Shape {
    private int soCanh;

    public int getSoCanh() {
        return soCanh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }

    public void print() {
        System.out.println("So canh = " + soCanh);
    }
}
