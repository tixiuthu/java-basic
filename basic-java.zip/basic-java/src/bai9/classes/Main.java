package bai9.classes;

/**
 * Created by nththuy on 12/12/18.
 */
public class Main {
    public static void main(String[] args) {
        Shape shape = new Square();
        shape.setSoCanh(4);
        shape.print();

        Circle circle = new Circle();
        circle.setSoCanh(0);
        circle.setBanKinh(9);
        System.out.println("Dien tich = " + circle.dienTich());


        Square square = new Square();
        square.setSoCanh(4);
        square.print();

    }
}
