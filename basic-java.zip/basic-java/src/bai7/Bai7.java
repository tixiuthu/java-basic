package bai7;

import java.util.*;

/**
 * Created by nththuy on 12/12/18.
 */
public class Bai7 {
    public static void main(String[] args) {
        List<String> a = new ArrayList<String>();
        ArrayList<String> a2 = new ArrayList<>();
        a.add("A");
        a.add("C");
        a.add("A");


        System.out.println(a);

        Set<String> s = new HashSet<>();
        s.add("A");
        s.add("A");
        s.add("B");
        System.out.println(s);

        s.addAll(a);

        System.out.println(s);

        Map<String, Long> map = new HashMap<>();

        map.put("6", 10l);
        map.put("6", 16l);

        map.put("2a", 30l);

        System.out.println(map);
        System.out.println(map.get("2a"));

    }
}
