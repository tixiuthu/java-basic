package bai5;

/**
 * Created by nththuy on 12/12/18.
 */
public class Student {

    private String name;
    private int age;
    private float mathScore;
    private float physicScore;
    private float hoaScore;

    public double avgScore() {
        return (this.mathScore + this.physicScore + this.hoaScore) / 3.0;
    }

    public double sumScore() {
        return this.mathScore + this.physicScore + this.hoaScore;
    }

    public char isDau(float dc) {
        return (sumScore() >= dc)? 'Y' : 'N';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getMathScore() {
        return mathScore;
    }

    public void setMathScore(float mathScore) {
        this.mathScore = mathScore;
    }

    public float getPhysicScore() {
        return physicScore;
    }

    public void setPhysicScore(float physicScore) {
        this.physicScore = physicScore;
    }

    public float getHoaScore() {
        return hoaScore;
    }

    public void setHoaScore(float hoaScore) {
        this.hoaScore = hoaScore;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", mathScore=" + mathScore +
                ", physicScore=" + physicScore +
                ", hoaScore=" + hoaScore +
                '}';
    }

}
