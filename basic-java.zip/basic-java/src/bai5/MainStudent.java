package bai5;

import java.util.Scanner;

/**
 * Created by nththuy on 12/12/18.
 */
public class MainStudent {




    public static void main(String[] args) {
        int n;
        Student[] students;
        float dcCNTT, dcDTVT, dcDT;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhap n: ");
        n = scanner.nextInt();

        students = new Student[n];

        for (int i = 0; i < students.length; i++) {
            scanner.nextLine();
            System.out.printf("Thong tin sinh vien %d\n", i);
            System.out.print("Nhap ten: ");
            students[i] = new Student();
            students[i].setName(scanner.nextLine());
            System.out.print("Nhap tuoi: ");
            students[i].setAge(scanner.nextInt());
            System.out.print("Diem Toan: ");
            students[i].setMathScore(scanner.nextFloat());;
            System.out.print("Diem Ly: ");
            students[i].setPhysicScore(scanner.nextFloat());;
            System.out.print("Diem Hoa: ");
            students[i].setHoaScore(scanner.nextFloat());;
        }

        for (Student student : students) {
            System.out.println(student.toString());
        }

        System.out.print("Diem chuan CNTT: ");
        dcCNTT = scanner.nextFloat();
        System.out.print("Diem chuan DTVT: ");
        dcDTVT = scanner.nextFloat();
        System.out.print("Diem chuan DT: ");
        dcDT = scanner.nextFloat();

        System.out.printf("Ten\tTong diem\tCNTT(%.2f)\tDTVT(%.2f)\tDT(%.2f)\n", dcCNTT, dcDTVT, dcDT);
        for (Student student : students) {
            System.out.println(student.getName() + "\t" + student.sumScore() + "\t"
                    + student.isDau(dcCNTT) + "\t" + student.isDau(dcDTVT) + "\t" + student.isDau(dcDT));
        }
    }



}
