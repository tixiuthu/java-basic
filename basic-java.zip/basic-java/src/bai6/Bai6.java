package bai6;

/**
 * Created by nththuy on 12/12/18.
 */
public class Bai6 {
    public static void main(String[] args) {
        String s1 = "Helloworld";
        String s2 = "Helloworld";
        String s3 = new String("Helloworld");

        System.out.println("S1 == S2 " + (s1 == s2));
        System.out.println("S1 == S3 " + (s1 == s3));
        System.out.println("S1 equals S3 " + (s1.equals(s3)));

        System.out.println("S1[3] = " + s1.charAt(3));
        System.out.println("S1[o] = " + s1.indexOf('o'));
        System.out.println("S1[o] = " + s1.lastIndexOf('o'));
        System.out.println("S1[o -> 5] = " + s1.indexOf('o', 5));

        System.out.println(s1.toLowerCase());
        System.out.println(s1.toUpperCase());

        String a = "lap trinh java co ban";
        String[] a2 = a.split(" ");
        System.out.println(a2.length);
    }
}
