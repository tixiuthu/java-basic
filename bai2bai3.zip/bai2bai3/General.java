package bai2bai3;

import java.util.Scanner;

/**
 * Created by nththuy on 12/6/18.
 */
public class General {


    private static int USCLN(int a, int b) {
        if (b == 0) return a;
        return USCLN(b, a % b);
    }


    /**
     * Tim boi so chung nho nhat (BSCNN)
     */
    private static int BSCNN(int a, int b) {
        return (a * b) / USCLN(a, b);
    }


    static void chuyenDoiCoSo(int n) {

        int coSo = 0, soDu = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap vao co so can chuyen");
        coSo = scanner.nextInt();
        String str = "";
        int i = 0;
        while (n > 0) {
            soDu = n % coSo;
            if (soDu < 10) {
                str += "0" + soDu;
            } else {
                str += "A" + (soDu - 10);
            }
            i++;
            n = n / coSo;
        }
        System.out.println("gia tri chuyen doi la " + str);
    }

    /**
     * check so nguyen to
     *
     * @param n: so nguyen duong
     * @return true la so nguyen so,
     * false khong la so nguyen to
     * @author viettuts.vn
     */
    public static boolean ktsonguyento(int n) {
        // so nguyen n < 2 khong phai la so nguyen to
        if (n < 2) {
            return false;
        }
        // check so nguyen to khi n >= 2
        int squareRoot = (int) Math.sqrt(n);
        for (int i = 2; i <= squareRoot; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }


    public static void insocacnguyento() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập n = ");
        int n = scanner.nextInt();
        System.out.printf("Tất cả các số nguyên tố nhỏ hơn %d là: \n", n);
        if (n >= 2) {
            System.out.print(2);
        }
        for (int i = 3; i < n; i += 2) {
            if (ktsonguyento(i)) {
                System.out.print(" " + i);
            }
        }

    }


    /**
     * @tong cua so n
     */
    public static int tongcacsocuan() {
        // TODO code application logic here
        int n, tong = 0;
        System.out.println("&quot;nhap vao so nguyen n&quot");
        Scanner input = new Scanner(System.in);
        n = input.nextInt();
        while (n > 0) {
            tong += n % 10;
            n = n / 10;
        }
        System.out.println("tong cac chu so cua n la: " + tong);
        return tong;
    }


    /**
     * @tong cua so n
     */
    public static int tinhFibonacci() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập n = ");
        int n = scanner.nextInt();
        int[] f = new int[n + 1];
        f[0] = 1;
        f[1] = 1;
        for (int i = 2; i <= n; i++) {
            f[i] = f[i - 1] + f[i - 2];
        }
        System.out.println("So Fibonanci thu " + n + " la: f[" + n + "]= " + f[n]);
        return f[n];

    }


    public static void main(String args[]) {
        System.out.println(USCLN(4, 6));
        Scanner scanner = new Scanner(System.in);
       /* System.out.println("Nhập vào a : ");
        int a = scanner.nextInt();
        System.out.println("Nhập vào b : ");
        int b = scanner.nextInt();
        System.out.println("uoc so chung cua hai so la "+USCLN(a, b));
        System.out.println("boi so chung lon nhat cua hai so la "+BSCNN(a, b));*/
        //  chuyenDoiCoSo(12);
        //  tongcacsocuan();
        //   insocacnguyento();
        tinhFibonacci();

    }


}
