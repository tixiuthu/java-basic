package bai4.employee;

/**
 * Created by nththuy on 12/12/18.
 */
public class Bai1 {


    public static void main(String[] args) {
        Employee employee1 = new Employee();
        employee1.setFirstName("Nguyen");
        employee1.setLastName("Thuy");
        employee1.setSalary(5000000);
        System.out.println(employee1.toString());

        Employee employee2 = new Employee();
        employee2.setFirstName("Pham");
        employee2.setLastName("Hoa");
        employee2.setSalary(7000000);
        System.out.println(employee2.toString());


    }
}
